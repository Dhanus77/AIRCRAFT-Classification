import os
import torch
from torchvision import transforms
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from transformers import ViTForImageClassification, ViTImageProcessor
import torch.optim as optim
from tqdm import tqdm

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Custom dataset class
class AircraftDataset(Dataset):
    def __init__(self, root_folder, transform=None, subset_size=None):
        self.root_folder = root_folder
        self.transform = transform
        self.image_paths = []
        self.labels = []
        self.class_names = sorted([d.name for d in os.scandir(root_folder) if d.is_dir()])
        self.class_to_idx = {class_name: idx for idx, class_name in enumerate(self.class_names)}
        
        # Load image paths and labels with optional subset size
        for class_name in self.class_names:
            class_folder = os.path.join(root_folder, class_name)
            img_files = [f for f in os.listdir(class_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            if subset_size:
                img_files = img_files[:subset_size]  # Limit number of images per class
            for img_file in img_files:
                self.image_paths.append(os.path.join(class_folder, img_file))
                self.labels.append(self.class_to_idx[class_name])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        image_path = self.image_paths[idx]
        label = self.labels[idx]
        try:
            image = Image.open(image_path).convert("RGB")  # Ensures image has 3 color channels
        except Exception as e:
            print(f"Error loading image {image_path}: {e}")
            return None, None

        if self.transform:
            image = self.transform(image)
        
        return image, label

# Define transforms with correct image size
feature_extractor = ViTImageProcessor.from_pretrained('google/vit-base-patch16-224-in21k')
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # Resize images to 224x224
    transforms.ToTensor(),
    transforms.Normalize(mean=feature_extractor.image_mean, std=feature_extractor.image_std)
])

# Load dataset and create DataLoader with a subset of data
train_folder = r"D:\aircraft_classification\dataset\fgvc-aircraft-2013b\train"
dataset = AircraftDataset(train_folder, transform=transform, subset_size=50)  # Use 50 images per class for testing
train_loader = DataLoader(dataset, batch_size=8, shuffle=True)

# Load a pre-trained ViT model and set up for training
model = ViTForImageClassification.from_pretrained(
    'google/vit-base-patch16-224-in21k', 
    num_labels=len(dataset.class_names), 
    ignore_mismatched_sizes=True
).to(device)

# Freeze all layers except for the classifier
for param in model.parameters():
    param.requires_grad = False
for param in model.classifier.parameters():
    param.requires_grad = True

model.train()  # Set model to training mode

# Define loss function and optimizer
criterion = torch.nn.CrossEntropyLoss()
optimizer = optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=5e-5)

# Training loop with mixed precision
scaler = torch.cuda.amp.GradScaler(enabled=device.type == 'cuda')  # Enable scaler only if CUDA is available
num_epochs = 5  # Adjust based on needs

for epoch in range(num_epochs):
    running_loss = 0.0
    for images, labels in tqdm(train_loader):
        # Filter out any images that failed to load
        images, labels = zip(*[(img, lbl) for img, lbl in zip(images, labels) if img is not None])

        if not images:  # Skip iteration if no valid images
            continue

        # Move data to device
        images = torch.stack(images).to(device)
        labels = torch.tensor(labels).to(device)
        
        optimizer.zero_grad()
        with torch.cuda.amp.autocast(enabled=device.type == 'cuda'):  # Enable mixed precision if CUDA is available
            outputs = model(images).logits
            loss = criterion(outputs, labels)
        
        scaler.scale(loss).backward()  # Scale loss for stability
        scaler.step(optimizer)
        scaler.update()
        running_loss += loss.item()
    

# Save the trained model
model.save_pretrained('trained_aircraft_model')
print("Model trained and saved.")
