from flask import Flask, request, render_template
from PIL import Image
import torch
from transformers import ViTForImageClassification, ViTImageProcessor
import os

app = Flask(__name__)

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the trained model
model_path = 'trained_aircraft_model'
model = ViTForImageClassification.from_pretrained(model_path).to(device)
model.eval()  # Set model to evaluation mode
feature_extractor = ViTImageProcessor.from_pretrained('google/vit-base-patch16-224-in21k')

# Load class names
train_folder = r"D:\aircraft_classification\dataset\fgvc-aircraft-2013b\train"
class_names = sorted([d.name for d in os.scandir(train_folder) if d.is_dir()])

def classify_image(image):
    """Classify a single image and return the predicted class name."""
    # Preprocess image
    image = feature_extractor(images=image, return_tensors="pt")["pixel_values"].to(device)

    # Perform prediction
    with torch.no_grad():
        outputs = model(image).logits
        predicted_class_index = outputs.argmax(-1).item()

    return class_names[predicted_class_index]

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    predicted_class = None
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file part'
        file = request.files['file']
        if file.filename == '':
            return 'No selected file'
        if file:
            # Load and convert the uploaded image
            img = Image.open(file).convert("RGB")  # Ensure image is in RGB mode
            predicted_class = classify_image(img)

    return render_template('index.html', predicted_class=predicted_class)

if __name__ == "__main__":
    app.run(debug=True)
